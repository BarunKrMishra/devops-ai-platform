import React, { useState, useEffect } from 'react';
import { GitBranch, Github, Gitlab, Play, Settings, CheckCircle } from 'lucide-react';
import axios from 'axios';

interface Repository {
  id: number;
  name: string;
  full_name: string;
  html_url: string;
  default_branch: string;
  language: string;
}

const CICDSetupPage: React.FC = () => {
  const [repositories, setRepositories] = useState<Repository[]>([]);
  const [selectedRepo, setSelectedRepo] = useState<Repository | null>(null);
  const [branch, setBranch] = useState('main');
  const [framework, setFramework] = useState('react');
  const [cloudProvider, setCloudProvider] = useState('aws');
  const [loading, setLoading] = useState(false);
  const [pipelineConfig, setPipelineConfig] = useState('');
  const [step, setStep] = useState(1);

  useEffect(() => {
    fetchRepositories();
  }, []);

  const fetchRepositories = async () => {
    try {
      const response = await axios.get('http://localhost:3001/api/cicd/repositories');
      setRepositories(response.data);
    } catch (error) {
      console.error('Failed to fetch repositories:', error);
    }
  };

  const handleCreatePipeline = async () => {
    if (!selectedRepo) return;

    setLoading(true);
    try {
      const response = await axios.post('http://localhost:3001/api/cicd/pipeline', {
        repositoryUrl: selectedRepo.html_url,
        branch,
        framework,
        cloudProvider
      });

      setPipelineConfig(response.data.pipelineConfig);
      setStep(3);
    } catch (error) {
      console.error('Failed to create pipeline:', error);
    } finally {
      setLoading(false);
    }
  };

  const frameworks = [
    { id: 'react', name: 'React', description: 'Modern React application' },
    { id: 'vue', name: 'Vue.js', description: 'Vue.js application' },
    { id: 'angular', name: 'Angular', description: 'Angular application' },
    { id: 'node', name: 'Node.js', description: 'Node.js backend service' },
    { id: 'python', name: 'Python', description: 'Python application' }
  ];

  const cloudProviders = [
    { id: 'aws', name: 'Amazon Web Services', icon: '☁️' },
    { id: 'gcp', name: 'Google Cloud Platform', icon: '🌐' },
    { id: 'azure', name: 'Microsoft Azure', icon: '🔷' }
  ];

  return (
    <div className="pt-20 min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-6 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">CI/CD Pipeline Setup</h1>
            <p className="text-gray-400">Set up automated deployment pipelines with AI assistance</p>
          </div>

          {/* Progress Steps */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              {[1, 2, 3].map((stepNum) => (
                <div key={stepNum} className="flex items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    step >= stepNum ? 'bg-purple-500 text-white' : 'bg-gray-600 text-gray-400'
                  }`}>
                    {step > stepNum ? <CheckCircle className="h-5 w-5" /> : stepNum}
                  </div>
                  {stepNum < 3 && (
                    <div className={`w-20 h-1 mx-4 ${
                      step > stepNum ? 'bg-purple-500' : 'bg-gray-600'
                    }`} />
                  )}
                </div>
              ))}
            </div>
            <div className="flex justify-between mt-2 text-sm text-gray-400">
              <span>Select Repository</span>
              <span>Configure Pipeline</span>
              <span>Deploy</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-8">
            {step === 1 && (
              <div>
                <h2 className="text-xl font-semibold text-white mb-6">Select Repository</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <button className="flex items-center space-x-3 p-4 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors">
                    <Github className="h-6 w-6 text-white" />
                    <span className="text-white">Connect GitHub</span>
                  </button>
                  <button className="flex items-center space-x-3 p-4 bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors">
                    <Gitlab className="h-6 w-6 text-white" />
                    <span className="text-white">Connect GitLab</span>
                  </button>
                </div>

                <div className="space-y-4">
                  {repositories.map((repo) => (
                    <div
                      key={repo.id}
                      onClick={() => setSelectedRepo(repo)}
                      className={`p-4 rounded-lg border cursor-pointer transition-all ${
                        selectedRepo?.id === repo.id
                          ? 'border-purple-400 bg-purple-500/20'
                          : 'border-white/20 bg-white/5 hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold text-white">{repo.name}</h3>
                          <p className="text-sm text-gray-400">{repo.full_name}</p>
                        </div>
                        <div className="text-right">
                          <span className="text-sm text-purple-400">{repo.language}</span>
                          <p className="text-xs text-gray-500">{repo.default_branch}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => setStep(2)}
                  disabled={!selectedRepo}
                  className="mt-6 px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Continue
                </button>
              </div>
            )}

            {step === 2 && (
              <div>
                <h2 className="text-xl font-semibold text-white mb-6">Configure Pipeline</h2>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Branch
                    </label>
                    <input
                      type="text"
                      value={branch}
                      onChange={(e) => setBranch(e.target.value)}
                      className="w-full p-3 bg-white/10 border border-white/20 rounded-lg text-white"
                      placeholder="main"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Framework
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {frameworks.map((fw) => (
                        <div
                          key={fw.id}
                          onClick={() => setFramework(fw.id)}
                          className={`p-4 rounded-lg border cursor-pointer transition-all ${
                            framework === fw.id
                              ? 'border-purple-400 bg-purple-500/20'
                              : 'border-white/20 bg-white/5 hover:bg-white/10'
                          }`}
                        >
                          <h3 className="font-semibold text-white">{fw.name}</h3>
                          <p className="text-sm text-gray-400">{fw.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Cloud Provider
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {cloudProviders.map((provider) => (
                        <div
                          key={provider.id}
                          onClick={() => setCloudProvider(provider.id)}
                          className={`p-4 rounded-lg border cursor-pointer transition-all ${
                            cloudProvider === provider.id
                              ? 'border-purple-400 bg-purple-500/20'
                              : 'border-white/20 bg-white/5 hover:bg-white/10'
                          }`}
                        >
                          <div className="text-center">
                            <div className="text-2xl mb-2">{provider.icon}</div>
                            <h3 className="font-semibold text-white text-sm">{provider.name}</h3>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex space-x-4 mt-8">
                  <button
                    onClick={() => setStep(1)}
                    className="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleCreatePipeline}
                    disabled={loading}
                    className="px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors disabled:opacity-50"
                  >
                    {loading ? 'Creating Pipeline...' : 'Create Pipeline'}
                  </button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div>
                <h2 className="text-xl font-semibold text-white mb-6">Pipeline Created Successfully!</h2>
                
                <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-4 mb-6">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-5 w-5 text-green-400" />
                    <span className="text-green-300">Your CI/CD pipeline has been configured</span>
                  </div>
                </div>

                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-white mb-3">Generated Pipeline Configuration</h3>
                  <pre className="bg-gray-900 p-4 rounded-lg text-sm text-gray-300 overflow-x-auto">
                    {pipelineConfig}
                  </pre>
                </div>

                <div className="flex space-x-4">
                  <button className="flex items-center space-x-2 px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors">
                    <Play className="h-4 w-4" />
                    <span>Deploy Now</span>
                  </button>
                  <button className="flex items-center space-x-2 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                    <Settings className="h-4 w-4" />
                    <span>Configure Settings</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CICDSetupPage;