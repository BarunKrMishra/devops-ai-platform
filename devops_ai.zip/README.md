# AI-Powered DevOps Assistant Platform

A comprehensive DevOps automation platform powered by artificial intelligence that helps developers deploy, scale, and manage their applications across multiple cloud providers.

## Features

### 🚀 Core Functionality
- **AI-Powered Assistant**: Natural language commands for DevOps operations
- **Multi-Cloud Support**: Deploy to AWS, GCP, and Azure
- **Automated CI/CD**: Intelligent pipeline generation and management
- **Infrastructure as Code**: Automated resource provisioning
- **Real-time Monitoring**: AI-driven monitoring and alerting
- **Auto-Healing**: Automatic issue detection and resolution
- **Cost Optimization**: AI-powered cost analysis and recommendations

### 🔐 Security & Compliance
- **Role-Based Access Control (RBAC)**: Admin, Developer, and Viewer roles
- **Audit Logging**: Comprehensive activity tracking
- **OAuth Integration**: GitHub and GitLab authentication
- **Two-Factor Authentication**: Enhanced security options
- **API Key Management**: Secure integration management

### 📊 Monitoring & Analytics
- **Real-time Metrics**: CPU, memory, network, and response time monitoring
- **Intelligent Alerts**: AI-powered incident detection
- **Performance Analytics**: Historical data and trend analysis
- **Cost Tracking**: Resource usage and cost optimization insights

## Technology Stack

### Frontend
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **React Router** for navigation
- **Axios** for API communication
- **Lucide React** for icons

### Backend
- **Node.js** with Express
- **PostgreSQL** database
- **JWT** authentication
- **Socket.io** for real-time updates
- **AWS SDK** for cloud integration
- **OpenAI API** for AI capabilities

### Infrastructure
- **Docker** containerization
- **AWS/GCP/Azure** cloud providers
- **GitHub Actions** for CI/CD
- **Terraform** for infrastructure provisioning

## Quick Start

### Prerequisites
- Node.js 18+ and npm
- PostgreSQL database
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd ai-devops-platform
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. **Set up the database**
   ```bash
   # Create PostgreSQL database
   createdb devops_ai
   
   # The application will automatically create tables on first run
   ```

5. **Start the development servers**
   ```bash
   npm run dev
   ```

   This will start both the frontend (port 5173) and backend (port 3001) servers.

6. **Access the application**
   - Frontend: http://localhost:5173
   - Backend API: http://localhost:3001

## Project Structure

```
src/
├── components/
│   ├── auth/              # Authentication components
│   ├── cicd/              # CI/CD pipeline management
│   ├── dashboard/         # Dashboard components
│   ├── infrastructure/    # Infrastructure management
│   ├── monitoring/        # Monitoring and alerts
│   ├── audit/             # Audit logs
│   └── settings/          # User settings
├── contexts/              # React contexts
└── utils/                 # Utility functions

server/
├── routes/                # API routes
├── middleware/            # Express middleware
├── database/              # Database configuration
└── utils/                 # Server utilities
```

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `POST /api/auth/github` - GitHub OAuth

### CI/CD
- `GET /api/cicd/repositories` - Get user repositories
- `POST /api/cicd/pipeline` - Create CI/CD pipeline
- `GET /api/cicd/pipelines` - Get user pipelines
- `POST /api/cicd/deploy/:projectId` - Trigger deployment

### Infrastructure
- `GET /api/infrastructure/overview` - Infrastructure overview
- `POST /api/infrastructure/provision` - Provision resources
- `GET /api/infrastructure/resources/:projectId` - Get project resources
- `POST /api/infrastructure/scale/:resourceId` - Scale resources

### Monitoring
- `GET /api/monitoring/metrics/:projectId` - Get metrics
- `GET /api/monitoring/alerts` - Get alerts
- `POST /api/monitoring/auto-heal/:resourceId` - Trigger auto-healing

### AI Assistant
- `POST /api/ai/command` - Process AI command
- `GET /api/ai/suggestions/:projectId` - Get AI suggestions
- `GET /api/ai/cost-optimization/:projectId` - Get cost recommendations

### Audit
- `GET /api/audit/logs` - Get audit logs (admin only)
- `GET /api/audit/my-logs` - Get user's audit logs
- `GET /api/audit/stats` - Get audit statistics

## Configuration

### Environment Variables

Create a `.env` file in the root directory with the following variables:

```env
# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=devops_ai
DB_USER=postgres
DB_PASSWORD=your-password

# JWT
JWT_SECRET=your-jwt-secret

# GitHub
GITHUB_TOKEN=your-github-token
GITHUB_CLIENT_ID=your-github-client-id
GITHUB_CLIENT_SECRET=your-github-client-secret

# AWS
AWS_ACCESS_KEY_ID=your-aws-access-key
AWS_SECRET_ACCESS_KEY=your-aws-secret-key
AWS_REGION=us-east-1

# OpenAI
OPENAI_API_KEY=your-openai-api-key

# Server
PORT=3001
NODE_ENV=development
```

### Database Setup

The application uses PostgreSQL. The database schema is automatically created when the server starts. Make sure you have PostgreSQL installed and running.

## Development

### Running Tests
```bash
npm test
```

### Building for Production
```bash
npm run build
```

### Linting
```bash
npm run lint
```

## Deployment

### Docker Deployment
```bash
# Build the Docker image
docker build -t ai-devops-platform .

# Run the container
docker run -p 3001:3001 -p 5173:5173 ai-devops-platform
```

### Cloud Deployment
The application can be deployed to any cloud provider that supports Node.js applications:

- **AWS**: Use Elastic Beanstalk or ECS
- **GCP**: Use App Engine or Cloud Run
- **Azure**: Use App Service
- **Heroku**: Direct deployment support

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support, email support@devops-ai.com or join our Slack community.

## Roadmap

- [ ] Kubernetes integration
- [ ] Multi-region deployments
- [ ] Advanced AI models
- [ ] Mobile application
- [ ] Enterprise SSO
- [ ] Advanced analytics dashboard
- [ ] Terraform integration
- [ ] Slack/Teams notifications
- [ ] Custom deployment strategies
- [ ] Advanced security scanning