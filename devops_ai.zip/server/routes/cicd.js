import express from 'express';
import { Octokit } from '@octokit/rest';
import { db } from '../database/init.js';
import { logAuditAction } from '../utils/audit.js';

const router = express.Router();

// Get user's repositories (GitHub)
router.get('/repositories', async (req, res) => {
  try {
    // In production, use user's actual GitHub token
    const octokit = new Octokit({
      auth: process.env.GITHUB_TOKEN
    });

    const { data } = await octokit.rest.repos.listForAuthenticatedUser({
      sort: 'updated',
      per_page: 50
    });

    res.json(data);
  } catch (error) {
    console.error('Repository fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch repositories' });
  }
});

// Create CI/CD pipeline (project)
router.post('/pipeline', async (req, res) => {
  try {
    const { repositoryUrl, branch, framework, cloudProvider } = req.body;
    const userId = req.user.id;

    // Create project
    const stmt = db.prepare(
      'INSERT INTO projects (user_id, name, repository_url, branch, framework, cloud_provider) VALUES (?, ?, ?, ?, ?, ?)'
    );
    const info = stmt.run(
      userId,
      repositoryUrl.split('/').pop(),
      repositoryUrl,
      branch,
      framework,
      cloudProvider
    );
    const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(info.lastInsertRowid);

    // Generate CI/CD configuration based on framework
    const pipelineConfig = generatePipelineConfig(framework, cloudProvider);

    // Log audit action
    await logAuditAction(userId, 'CREATE_PIPELINE', 'project', project.id, {
      repository: repositoryUrl,
      framework,
      cloudProvider
    });

    res.json({
      project,
      pipelineConfig
    });
  } catch (error) {
    console.error('Pipeline creation error:', error);
    res.status(500).json({ error: 'Failed to create pipeline' });
  }
});

// Get project pipelines (for current user)
router.get('/pipelines', async (req, res) => {
  try {
    const userId = req.user.id;
    const projects = db.prepare(
      'SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC'
    ).all(userId);

    // Get recent deployments for each project
    const projectsWithDeployments = projects.map((project) => {
      const deployments = db.prepare(
        'SELECT * FROM deployments WHERE project_id = ? ORDER BY created_at DESC LIMIT 5'
      ).all(project.id);
      return {
        ...project,
        deployments
      };
    });

    res.json(projectsWithDeployments);
  } catch (error) {
    console.error('Pipelines fetch error:', error);
    res.status(500).json({ error: 'Failed to fetch pipelines' });
  }
});

// Trigger deployment
router.post('/deploy/:projectId', async (req, res) => {
  try {
    const { projectId } = req.params;
    const { environment = 'production' } = req.body;
    const userId = req.user.id;

    // Get project
    const project = db.prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?').get(projectId, userId);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Create deployment record
    const insertStmt = db.prepare(
      'INSERT INTO deployments (project_id, status, environment, commit_hash) VALUES (?, ?, ?, ?)'
    );
    const info = insertStmt.run(projectId, 'running', environment, 'latest');
    const deployment = db.prepare('SELECT * FROM deployments WHERE id = ?').get(info.lastInsertRowid);

    // Simulate deployment process
    setTimeout(() => {
      const success = Math.random() > 0.2; // 80% success rate
      const duration = Math.floor(Math.random() * 300) + 60; // 1-5 minutes

      db.prepare(
        'UPDATE deployments SET status = ?, duration = ? WHERE id = ?'
      ).run(success ? 'success' : 'failed', duration, deployment.id);
    }, 2000);

    // Log audit action
    await logAuditAction(userId, 'TRIGGER_DEPLOYMENT', 'deployment', deployment.id, {
      projectId,
      environment
    });

    res.json(deployment);
  } catch (error) {
    console.error('Deployment error:', error);
    res.status(500).json({ error: 'Failed to trigger deployment' });
  }
});

// Helper: Generate pipeline config
function generatePipelineConfig(framework, cloudProvider) {
  const configs = {
    'react': {
      'aws': `
name: Deploy React App to AWS
on:
  push:
    branches: [ main ]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Setup Node.js
      uses: actions/setup-node@v2
      with:
        node-version: '18'
    - name: Install dependencies
      run: npm install
    - name: Build
      run: npm run build
    - name: Deploy to S3
      run: aws s3 sync dist/ s3://\${{ secrets.S3_BUCKET }}
      `,
      'gcp': `
name: Deploy React App to GCP
on:
  push:
    branches: [ main ]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Setup Node.js
      uses: actions/setup-node@v2
      with:
        node-version: '18'
    - name: Install dependencies
      run: npm install
    - name: Build
      run: npm run build
    - name: Deploy to Cloud Storage
      run: gsutil -m rsync -r -d dist/ gs://\${{ secrets.GCS_BUCKET }}
      `
    }
  };

  return configs[framework]?.[cloudProvider] || configs['react']['aws'];
}

export default router;