import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db } from '../database/init.js';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

// Allowed roles for registration
const ALLOWED_ROLES = ['developer', 'manager', 'user'];

// Register
router.post('/register', async (req, res) => {
  try {
    const { email, password, role = 'developer' } = req.body;

    // Validate role
    if (!ALLOWED_ROLES.includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    // Check if user exists
    const existingUser = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, 10);

    // Default organization ID is 1
    const result = db.prepare(
      'INSERT INTO users (email, password_hash, role, organization_id) VALUES (?, ?, ?, ?)'
    ).run(email, passwordHash, role, 1);

    const user = {
      id: result.lastInsertRowid,
      email,
      role,
      organization_id: 1
    };

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, organization_id: user.organization_id },
      JWT_SECRET
    );

    res.json({ token, user });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Check password
    const validPassword = await bcrypt.compare(password, user.password_hash);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, organization_id: user.organization_id },
      JWT_SECRET
    );

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        organization_id: user.organization_id
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// GitHub OAuth (simplified - in production, use proper OAuth flow)
router.post('/github', async (req, res) => {
  try {
    const { code } = req.body;

    // In a real implementation, exchange code for access token with GitHub
    // For demo purposes, we'll simulate this
    const mockGitHubUser = {
      id: '12345',
      email: 'user@github.com',
      login: 'githubuser'
    };

    // Check if user exists
    let user = db.prepare('SELECT * FROM users WHERE github_id = ?').get(mockGitHubUser.id);

    if (!user) {
      // Create new user with developer role
      const result = db.prepare(
        'INSERT INTO users (email, github_id, role, organization_id) VALUES (?, ?, ?, ?)'
      ).run(mockGitHubUser.email, mockGitHubUser.id, 'developer', 1);

      user = {
        id: result.lastInsertRowid,
        email: mockGitHubUser.email,
        github_id: mockGitHubUser.id,
        role: 'developer',
        organization_id: 1
      };
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, organization_id: user.organization_id },
      JWT_SECRET
    );

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        organization_id: user.organization_id
      }
    });
  } catch (error) {
    console.error('GitHub OAuth error:', error);
    res.status(500).json({ error: 'GitHub authentication failed' });
  }
});

export default router;