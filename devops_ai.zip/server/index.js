import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { createServer } from 'http';
import { Server } from 'socket.io';
import authRoutes from './routes/auth.js';
import cicdRoutes from './routes/cicd.js';
import infrastructureRoutes from './routes/infrastructure.js';
import monitoringRoutes from './routes/monitoring.js';
import aiRoutes from './routes/ai.js';
import auditRoutes from './routes/audit.js';
import templatesRoutes from './routes/templates.js';
import notificationsRoutes from './routes/notifications.js';
import organizationsRoutes from './routes/organizations.js';
import webhooksRoutes from './routes/webhooks.js';
import alertsRoutes from './routes/alerts.js';
import { authenticateToken } from './middleware/auth.js';
import { initDatabase } from './database/init.js';

const app = express();
const server = createServer(app);
const io = new Server(server, {
  cors: {
    origin: "http://localhost:5173",
    methods: ["GET", "POST"]
  }
});

const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Initialize database
await initDatabase();

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/cicd', authenticateToken, cicdRoutes);
app.use('/api/infrastructure', authenticateToken, infrastructureRoutes);
app.use('/api/monitoring', authenticateToken, monitoringRoutes);
app.use('/api/ai', authenticateToken, aiRoutes);
app.use('/api/audit', authenticateToken, auditRoutes);
app.use('/api/templates', authenticateToken, templatesRoutes);
app.use('/api/notifications', authenticateToken, notificationsRoutes);
app.use('/api/organizations', authenticateToken, organizationsRoutes);
app.use('/api/webhooks', authenticateToken, webhooksRoutes);
app.use('/api/alerts', authenticateToken, alertsRoutes);

// WebSocket connection for real-time updates
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);
  
  socket.on('join-room', (userId) => {
    socket.join(`user-${userId}`);
  });

  socket.on('join-org', (orgId) => {
    socket.join(`org-${orgId}`);
  });

  socket.on('join-project', (projectId) => {
    socket.join(`project-${projectId}`);
  });

  // Real-time collaboration features
  socket.on('typing', (data) => {
    socket.to(`project-${data.projectId}`).emit('user-typing', {
      userId: data.userId,
      userName: data.userName
    });
  });

  socket.on('stop-typing', (data) => {
    socket.to(`project-${data.projectId}`).emit('user-stop-typing', {
      userId: data.userId
    });
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export { io };